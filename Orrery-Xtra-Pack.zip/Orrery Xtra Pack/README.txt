ORRERY XTRA PACK
Free expansion for Orrery, by Renger Koning

What is inside
  23 patches   (folder "Patches")        all start with "Xtra"
  64 sounds    (folder "Orrery Xtra")    modular synth, guitar and percussion hits, 48 kHz / 24 bit

The sounds come from Renger's own modular system. Most of them are short, odd and a bit
rough on purpose. Try "Xtra Tom Tom Club", "Xtra Paris Texas" and "Xtra Sub Walk" first.

INSTALL (2 steps, about one minute)

macOS
  1. Drag the folder "Orrery Xtra" into  /Users/Shared/Orrery/Content/
     (next to "Factory Sounds").
  2. Drag the files from "Patches" into  ~/Music/Orrery/Patches/
     (in Finder: Go > Go to Folder, paste the path).
  Then restart your DAW, or rescan in Orrery, and look for the patches starting with "Xtra".

Windows
  1. Copy the folder "Orrery Xtra" into  C:\Users\Public\Documents\Orrery\Content\
  2. Copy the files from "Patches" into  C:\Users\<your name>\Music\Orrery\Patches\
  Then restart your DAW, or rescan in Orrery.

Important: keep the folder name "Orrery Xtra" exactly as it is. If a patch loads without sound,
the sounds folder is in the wrong place.

Uninstall: delete the "Orrery Xtra" folder and the patches that start with "Xtra".

Terms
  Free to use in your own music, commercial or not. Please do not redistribute the sounds
  as a sample pack or sell them.

More from Renger: renger.shop
Questions or something not working? Mail support@renger.shop
